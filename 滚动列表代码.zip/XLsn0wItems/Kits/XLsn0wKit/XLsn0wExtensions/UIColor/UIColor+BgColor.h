

#import <UIKit/UIKit.h>

@interface UIColor (BgColor)

+(UIColor*) colorWithRGB:(NSUInteger)rgb;

@end
