
#import <Foundation/Foundation.h>

@interface NSMutableArray (XLsn0w)

- (void)moveObjectFromIndex:(NSUInteger)from toIndex:(NSUInteger)to;

@end
