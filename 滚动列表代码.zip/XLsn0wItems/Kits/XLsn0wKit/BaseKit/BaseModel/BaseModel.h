
#import <Foundation/Foundation.h>

@interface BaseModel : NSObject <YYModel>

@end
