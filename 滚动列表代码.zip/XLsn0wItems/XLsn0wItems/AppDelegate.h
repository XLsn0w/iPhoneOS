//
//  AppDelegate.h
//  XLsn0wItems
//
//  Created by XLsn0w on 2020/3/6.
//  Copyright © 2020 XLsn0w. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

